/**
 * Lab 4 Demo
 * Demonstrate using the command line, git, polymorphism, and unit tests
 * 
 * @author MoSho
 * @version 02-07-2019
 */
 public class Person
 {
     private String name;
     private int age;
     
     public Person()
     {
         name = "";
         age = 0;
     }
     
     public Person(String n, int a)
     {
         name = n;
         age = a;
     }
     
     public String getName() { return name; }
     public int getAge() { return age; }
     
     public void setName(String n) { name = n; }
     public void setAge(int a) { age = a; }
     
     
     public String getTaskList()
     {
         return " 1. Walk dog\n 2. Bath\n 3. Eat breakfast\n 4. Make lunch\n" + 
                " 5. Go to work\n 6. Go to gym\n 7. Fall asleep watching Netflix";
     }
     
     
     public static void main(String[] args)
     {
         Person me = new Person("MoSho", 25);
         Hero b_man = new Hero("Batman", 39);
         
         System.out.println(" My TODO List:\n" + me.getTaskList());
         System.out.println("\n");
         System.out.println(" Batman's TODO List:\n" + b_man.getTaskList());
     }
     
 }