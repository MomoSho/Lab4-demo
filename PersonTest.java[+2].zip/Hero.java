/**
 * 
 * @author MoSho
 * @version 02-07-2019
 */
 public class Hero extends Person
 {
     private String name;
     private int age;
     
     public Hero()
     {
         super();
     }
     
     public Hero(String n, int a)
     {
         super(n, a);
         System.out.println("SUPER: " + super.getName() + " " + super.getAge());
         System.out.println("THIS: " + this.getName() + " " + this.getAge());
         System.out.println("THIS: " + this.name + " " + this.age);
     }
     
     
     @Override
     public String getTaskList()
     {
         return " 1. Eat breakfast\n 2. Make lunch\n 3. Go to work\n" +
                " 4. Go on patrol\n 5. Kick some ass\n 6. Wash up";
     }
 }