/**
 * 
 * 
 * 
 */

import org.junit.Assert;
import org.junit.Test;
 
public class PersonTest
{
    
    @Test
    public void testEmptyConstructor()
    {
        String noname = "";
        int noage = 0;
        Person per1 = new Person();
        Person per2 = new Person();
        
        Assert.assertEquals("Empty person1's name incorrect. Should have no name", noname, per1.getName());
        Assert.assertEquals("Empty person1's age incorrect. Should have no age", noage, per1.getAge());
        
        Assert.assertEquals("Empty person2's name incorrect. Should have no name", noname, per2.getName());
        Assert.assertEquals("Empty person2's age incorrect. Should have no age", noage, per2.getAge());
    }
    
    @Test
    public void testConstructor()
    {
        String name1 = "Fetus";
        int age1 = -1;
        Person per1 = new Person(name1, age1);
        
        String name2 = "New Born";
        int age2 = 0;
        Person per2 = new Person(name2, age2);
        
        String name3 = "Trump";
        int age3 = 75;
        Person per3 = new Person(name3, age3);
        
        String name4 = "Jesus";
        int age4 = 2019;
        Person per4 = new Person(name4, age4);
        
        Assert.assertEquals("Empty person1's name incorrect. Should have no name", name1, per1.getName());
        Assert.assertEquals("Empty person1's age incorrect. Should have no age", age1, per1.getAge());
        
        Assert.assertEquals("Empty person2's name incorrect. Should have no name", name2, per2.getName());
        Assert.assertEquals("Empty person2's age incorrect. Should have no age", age2, per2.getAge());
        
        Assert.assertEquals("Empty person3's name incorrect. Should have no name", name3, per3.getName());
        Assert.assertEquals("Empty person3's age incorrect. Should have no age", age3, per3.getAge());
        
        Assert.assertEquals("Empty person4's name incorrect. Should have no name", name4, per4.getName());
        Assert.assertEquals("Empty person4's age incorrect. Should have no age", age4, per4.getAge());
    }
    
}